package CurrencyCalc;

import java.util.Scanner;

public class pound {

	public void convertpound()
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("How many Pounds you want to convert:-");
		int a=sc.nextInt();
		int b=a*75;
		System.out.println(a+" "+ "Pounds are equal to:- "+" "+b);

	}

}
