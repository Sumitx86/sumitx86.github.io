package sdbms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

public class update {

	public void dataupdate( ) {String choice; 
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter Sr no of the row ");
	int a=sc.nextInt();
		
	try{
	/* for printing the Existing data of table */	   
		Class.forName("oracle.jdbc.driver.OracleDriver");//fully qualified class name
	    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "myresult", "myresult");
		Statement stmt=con.createStatement();

		   String r="Select *from student where srno ="+a ;
		   ResultSet rs =  stmt.executeQuery(r);
		   System.out.println("DATA  OF STUDENT TABLE ");//assume that EMP is already created;
		   while(rs.next() )
		   {
		   	int a1= rs.getInt(1);
		   	System.out.print(a1+ "  " );
		   	
		   	String b1=rs.getString(2);
		   	System.out.print(b1 + "      ");
		   	
		   	String c1=rs.getString(3);
		   	System.out.print(c1 + " ");
		   	
		   	int d1= rs.getInt(4);
		   	System.out.print(d1+ "  " );
		   	
		   	String e1=rs.getString(5);
		   	System.out.print(e1 +" " );
		       
		   	System.out.println("\n");
		   }     
		   
System.out.println("******************************************************");
		
		
		do{
			System.out.println("Press q for updating Name");
			System.out.println("Press w For updating sub ");
			System.out.println("Press e for updating marks");
			System.out.println("Press r for exit");
			String option =sc.next();
			char c = option.charAt(0);
			switch(c)
				{
				case 'q':
				case 'Q':
				System.out.println("Enter the Updated Name");	
				String name=sc.next();	
				String b1="update student set sname='"+name+ "'where srno=" +a ;
			    stmt.execute(b1);
				break;
				
				case'w':
				case 'W':
					System.out.println("Enter the Updated Subject");	
					String sub=sc.next();	
					String b2="update student set sub='"+sub+ "'where srno=" +a ;
				    stmt.execute(b2);
					break;
				
				case'e':
				case 'E':
					System.out.println("Enter the Updated Name");	
					int marks=sc.nextInt();	
					String b3="update student set marks='"+marks+ "'where srno=" +a ;
				    stmt.execute(b3);
				break;
				case 'X':
				case 'x':
				System.exit(0);
				break;
				default:
				System.out.println("Sorry your choice is wrong:");
				}
			    System.out.println("Do you want to continue data updation y/n"); 
				Scanner Stdin =new Scanner(System.in);
				choice =Stdin.next();
				}
				while(choice.charAt(0)!= 'n');
			
	
	    String r1="Select *from student where srno ="+a ;
	    ResultSet rs1 =  stmt.executeQuery(r1);
	    System.out.println("DATA  OF STUDENT TABLE ");//assume that EMP is already created;
	    while(rs1.next() )
	    {
	   	int a1= rs1.getInt(1);
	   	System.out.print(a1+ "  " );
	   	
	   	String b1=rs1.getString(2);
	   	System.out.print(b1 + "      ");
	   	
	   	String c1=rs1.getString(3);
	   	System.out.print(c1 + " ");
	   	
	   	int d1= rs1.getInt(4);
	   	System.out.print(d1+ "  " );
	   	
	   	String e1=rs1.getString(5);
	   	System.out.print(e1 +" " );
	       
	   	System.out.println("\n");
	   }     
	  
	}
	
    catch(Exception e)
	{
    	System.out.println("some errror "+e);
	}
	
	}}
		
		

	
	
	
	
	
	
		
	

		