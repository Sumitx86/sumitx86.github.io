package CurrencyCalc;

import java.util.Scanner;

public class doller {

		public  void convertdoller ()
		{
			Scanner sc =new Scanner(System.in);
			System.out.println("How many Dollers you want to convert:-");
			int a=sc.nextInt();
			int b=a*65;
			System.out.println(a+" "+ "dollers are equal to:- "+" "+b);

	}

}
