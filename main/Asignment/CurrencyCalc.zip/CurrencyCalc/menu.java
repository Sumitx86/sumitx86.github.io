package CurrencyCalc;

import java.util.Scanner;

public class menu{
	   public static void main(String args[])
	{
		String choice; 
	try
	{
System.out.println("***********************************************************************");
System.out.println("                 "+ "Welcome to Currency Convert System:");
System.out.println("***********************************************************************");

	do{
	System.out.println("Press d to convert doller to Rs");
	System.out.println("Press e to convert Euro to Rs");
	System.out.println("Press p to convert Pound to Rs");
	System.out.println("Press x for exit");
	Scanner sc =new Scanner(System.in);
	String option =sc.next();
	char c = option.charAt(0);
	switch(c)
		{
		case 'D':
		case 'd':
	 	doller I= new  doller();
		I.convertdoller();
		break;
		
		case'E':
		case 'e':
		euro su =new euro();
		su.converteuro();
		break;
		
		case'P':
		case 'p':
		pound mu=new pound();
		mu.convertpound();
		break;
		
		case 'X':
		case 'x':
		System.exit(0);
		break;
		default:
		System.out.println("Sorry your choice is wrong:");
		}
	    System.out.println("Do you want to continue y/n"); 
		Scanner Stdin =new Scanner(System.in);
		choice =Stdin.next();
		}
		while(choice.charAt(0)!= 'n');
		}
	catch(Exception e){
		System.out.println(e);
		}
		}

		}
