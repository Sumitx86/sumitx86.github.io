package sdbmsWithPrepared;

import java.sql.*;
import java.util.Scanner;

public class incert {

	public  void dataincert()  {String m;String choice; 
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","myresult ","myresult ");
		PreparedStatement pstmt=con.prepareStatement("insert into student values (?,?, ?, ?,?)");
		Statement stmt=con.createStatement();


		do{
		Scanner sc=new Scanner(System.in);
		System.out.println("id  of student");
	    int a=sc.nextInt();
	    System.out.println("Name  of student");
	    String b=sc.next();
	    System.out.println("Subject of student");
	    String c=sc.next();
	    System.out.println("Marks  of student");
	    int d=sc.nextInt();
	    if(d > 60)
	    {m="Pass";}
	    else
	    {m="fail";}	
	    pstmt.setInt(1, a);
	    pstmt.setString(2, b);
	    pstmt.setString(3, c);
	    pstmt.setInt(4, d);
	    pstmt.setString(5, m);
	    pstmt.execute();
	    System.out.println("Do you want to continue y/n"); 
		choice =sc.next();
		}
		while(choice.charAt(0)!= 'n');
		System.out.println("record Entered");
	    
		String r="Select *from student ";
		   ResultSet rs =  stmt.executeQuery(r);
		   System.out.println("DATA  OF STUDENT TABLE ");
		   while(rs.next() )
		   {
		   	int a1= rs.getInt(1);
		   	System.out.print(a1+ "  " );
		   	String b1=rs.getString(2);
		   	System.out.print(b1 + "      ");
		   	String c1=rs.getString(3);
		   	System.out.print(c1 + " ");
		   	int d1= rs.getInt(4);
		   	System.out.print(d1+ "  " );
		   	String e1=rs.getString(5);
		   	System.out.print(e1 +" " );
		   	System.out.println("\n");
		}  


	
	}

	catch(Exception e)
	{System.out.println("some errror");
		}}}
