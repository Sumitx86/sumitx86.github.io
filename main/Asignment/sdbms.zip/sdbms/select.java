package sdbms;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class select {
	public void dataselect( ) {

		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","myresult ","myresult ");
			Statement stmt=con.createStatement();
		    Scanner sc=new Scanner(System.in);

		    System.out.println("Enter the Srno of row for viewing the data");
		    int a=sc.nextInt();
		    
		    String r="Select *from student where srno=" +a;
		    ResultSet rs =  stmt.executeQuery(r);
		    System.out.println("DATA  OF STUDENT TABLE ");//assume that EMP is already created;
		    while(rs.next() )
		    {
		   	int a1= rs.getInt(1);
		   	System.out.print(a1+ "  " );
		   	
		   	String b1=rs.getString(2);
		   	System.out.print(b1 + "      ");
		   	
		   	String c1=rs.getString(3);
		   	System.out.print(c1 + " ");
		   	
		   	int d1= rs.getInt(4);
		   	System.out.print(d1+ "  " );
		   	
		   	String e1=rs.getString(5);
		   	System.out.print(e1 +" " );
		       
		   	System.out.println("\n");
		}  
		   }

		catch(Exception e)
		{System.out.println("some errror");
			}}}