package sdbms;
import java.sql.*;
import java.util.*;

public class insert {

public void datainsert( ) {
try{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","myresult ","myresult ");
	Statement stmt=con.createStatement();
    Scanner sc=new Scanner(System.in);

    System.out.println("Serial number no of student");
    int a=sc.nextInt();
    System.out.println("Name  of student");
    String b=sc.next();
    System.out.println("Subject of student");
    String c=sc.next();
    System.out.println("Marks  of student");
    int d=sc.nextInt();
    System.out.println("Status of student");
    String e=sc.next();
    String q="insert into student values("+a+" ,' "+b+" ',' "+c+" ', "+d+ ",'" +e+ "')" ;
    stmt.execute(q);

    
   String r="Select *from student ";
   ResultSet rs =  stmt.executeQuery(r);
   System.out.println("DATA  OF STUDENT TABLE ");//assume that EMP is already created;
   while(rs.next() )
   {
   	int a1= rs.getInt(1);
   	System.out.print(a1+ "  " );
   	
   	String b1=rs.getString(2);
   	System.out.print(b1 + "      ");
   	
   	String c1=rs.getString(3);
   	System.out.print(c1 + " ");
   	
   	int d1= rs.getInt(4);
   	System.out.print(d1+ "  " );
   	
   	String e1=rs.getString(5);
   	System.out.print(e1 +" " );
       
   	System.out.println("\n");
}  
   }

catch(Exception e)
{System.out.println("some errror");
	}}}
