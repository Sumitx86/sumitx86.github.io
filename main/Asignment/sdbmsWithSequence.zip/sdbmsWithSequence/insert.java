package sdbmsWithSequence;
import java.sql.*;
import java.util.*;

public class insert {

public void datainsert( ) {String m;
try{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","myresult ","myresult ");
	Statement stmt=con.createStatement();
    Scanner sc=new Scanner(System.in);

    System.out.println("Name  of student");
    String b=sc.next();
    System.out.println("Subject of student");
    String c=sc.next();
    System.out.println("Marks  of student");
    int d=sc.nextInt();
    if(d > 60)
    {m="Pass";}
    else
    {m="fail";}	
    String q="insert into student values(DEPT_DEPTID_SEQ.NEXTVAL" +",' "+b+" ',' "+c+" ', "+d+ ",'" +m+ "')" ;
    stmt.execute(q);

    
   String r="Select *from student ";
   ResultSet rs =  stmt.executeQuery(r);
   System.out.println("DATA  OF STUDENT TABLE ");//assume that EMP is already created;
   while(rs.next() )
   {
   	int a1= rs.getInt(1);
   	System.out.print(a1+ "  " );
   	
   	String b1=rs.getString(2);
   	System.out.print(b1 + "      ");
   	
   	String c1=rs.getString(3);
   	System.out.print(c1 + " ");
   	
   	int d1= rs.getInt(4);
   	System.out.print(d1+ "  " );
   	
   	String e1=rs.getString(5);
   	System.out.print(e1 +" " );
       
   	System.out.println("\n");
}  
   }

catch(Exception e)
{System.out.println("some errror");
	}}}
