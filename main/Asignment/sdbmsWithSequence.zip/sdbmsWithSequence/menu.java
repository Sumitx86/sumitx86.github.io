package sdbmsWithSequence;
import java.util.Scanner;
public class menu {
	public static void main(String[] args) {

		String choice; 
		try
		{
	System.out.println("***********************************************************************");
	System.out.println("                 "+ "Welcome to Student DBMS System:");
	System.out.println("***********************************************************************");

		do{
		System.out.println("Press A adding values in database");
		System.out.println("Press V For Viewing data of table ");
		System.out.println("Press D for delete row of table");
		System.out.println("Press U for update row of table");
		System.out.println("Press x for exit");
		Scanner sc =new Scanner(System.in);
		String option =sc.next();
		char c = option.charAt(0);
		switch(c)
			{
			case 'a':
			case 'A':
		 	insert I= new  insert();
			I.datainsert();
			break;
			
			case'U':
			case 'u':
			update mu=new update();
			mu.dataupdate();
			break;
			
			
			case'V':
			case 'v':
			select su =new select();
			su.dataselect();
			break;
			
			case'D':
			case 'd':
			delete mu1=new delete();
			mu1.datadelete();
			break;
			
			
			case 'X':
			case 'x':
			System.exit(0);
			break;
			default:
			System.out.println("Sorry your choice is wrong:");
			}
		    System.out.println("Do you want to continue y/n"); 
			Scanner Stdin =new Scanner(System.in);
			choice =Stdin.next();
			}
			while(choice.charAt(0)!= 'n');
			}
		catch(Exception e){
			System.out.println(e);
			}
			}

			}
