package CurrencyCalc;

import java.util.Scanner;

public class euro {

	public void converteuro ()
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("How many rupees you want to convert:-");
		int a=sc.nextInt();
		int b=a*70;
		System.out.println(a+" "+ "Euros are equal to:- "+" "+b);

	}

}
