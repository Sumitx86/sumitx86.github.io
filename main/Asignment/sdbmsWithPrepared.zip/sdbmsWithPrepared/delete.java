package sdbmsWithPrepared;
import java.sql.*;
import java.util.Scanner;
public class delete {

	public void datadelete( ) { 
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","myresult ","myresult ");
		PreparedStatement pstmt=con.prepareStatement("delete from student where srno = ?");
		System.out.println("Enter Srno of the row");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		pstmt.setInt(1, a);
		pstmt.execute();
        System.out.println("data deleted");
	}
     catch(Exception e)
	{System.out.println("some errror");
	}}}

