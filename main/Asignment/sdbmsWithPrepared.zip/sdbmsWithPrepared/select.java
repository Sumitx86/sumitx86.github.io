package sdbmsWithPrepared;

import java.sql.*;

public class select {

	public void dataselect( ) { 
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","myresult ","myresult ");
		Statement stmt=con.createStatement();
 		String r="Select *from student ";
		   ResultSet rs =  stmt.executeQuery(r);
		   System.out.println("DATA  OF STUDENT TABLE ");
		   while(rs.next() )
		   {
		   	int a1= rs.getInt(1);
		   	System.out.print(a1+ "  " );
		   	String b1=rs.getString(2);
		   	System.out.print(b1 + "      ");
		   	String c1=rs.getString(3);
		   	System.out.print(c1 + " ");
		   	int d1= rs.getInt(4);
		   	System.out.print(d1+ "  " );
		   	String e1=rs.getString(5);
		   	System.out.print(e1 +" " );
		   	System.out.println("\n");
		}  


	
	}

	catch(Exception e)
	{System.out.println("some errror");
		}}}
