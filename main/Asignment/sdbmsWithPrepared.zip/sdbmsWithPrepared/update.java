package sdbmsWithPrepared;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class update {

	public void dataupdate( ) {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","myresult","myresult");
			PreparedStatement stmt=con.prepareStatement("update student set sname=? where srno=?");
			System.out.println("input updated name");
			Scanner sc=new Scanner(System.in);
			String name=sc.next(); 
			System.out.println("Input srno where you want to perform changes");
			int srno=sc.nextInt();
			stmt.setString(1,name);//1 specifies the first parameter in the query i.e. name
			stmt.setInt(2,srno);
			int i=stmt.executeUpdate();
			System.out.println(i+" records updated");
			}catch(Exception e){ System.out.println(e);}
			}
			}